package com.example.moviecatalog.data.source.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}