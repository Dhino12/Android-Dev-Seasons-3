package com.example.moviecatalog.data.source.local

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class GenreTvDetailEntity (
    val name:String?
):Parcelable