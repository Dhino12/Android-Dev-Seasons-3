package com.example.moviecatalog.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.moviecatalog.data.source.FilmRepository
import com.example.moviecatalog.data.source.local.TvEntitys
import com.example.moviecatalog.data.source.local.UpcomingTvEntity

class TvViewModel(private val filmRepository: FilmRepository) :ViewModel(){

    fun getTvPop():LiveData<List<TvEntitys>> = filmRepository.getAllTv()

    fun getUpcomingTv():LiveData<List<UpcomingTvEntity>> = filmRepository.getUpcomingTv()
}