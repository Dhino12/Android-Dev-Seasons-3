package com.example.moviecatalog.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.moviecatalog.data.source.FilmRepository
import com.example.moviecatalog.data.source.local.MovieEntitys
import com.example.moviecatalog.data.source.local.UpcomingMovieEntity

class MovieViewModel(private val filmRepository: FilmRepository): ViewModel() {

    fun getMovies():LiveData<List<MovieEntitys>> = filmRepository.getAllMovies()

    fun getUpMovies():LiveData<List<UpcomingMovieEntity>> = filmRepository.getUpcomingMovie()
}