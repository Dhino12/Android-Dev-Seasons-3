package com.example.moviecatalog.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.moviecatalog.data.source.local.MovieDetailEntity
import com.example.moviecatalog.data.source.FilmRepository
import com.example.moviecatalog.data.source.local.GenreMovieDetailEntity
import com.example.moviecatalog.data.source.local.MovieTrailerEntity

class DetailMovieViewModel(private val filmRepository: FilmRepository): ViewModel() {

    private var movieID:Int? = null

    fun setSelectedFilms(movieID:Int?){
        this.movieID = movieID
    }

    fun getDetail():LiveData<MovieDetailEntity> = filmRepository.getMovieDetail(movieID)

    fun getGenreDetail():LiveData<List<GenreMovieDetailEntity>> = filmRepository.getMovieGenre(movieID)

    fun getTrailer():LiveData<List<MovieTrailerEntity>> = filmRepository.getTrailerMovie(movieID)
}