package com.example.moviecatalog.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.moviecatalog.data.source.FilmRepository
import com.example.moviecatalog.data.source.local.GenreTvDetailEntity
import com.example.moviecatalog.data.source.local.TvDetailEntity
import com.example.moviecatalog.data.source.local.TvTrailerEntity

class DetailTVViewModel(private val filmRepository: FilmRepository):ViewModel() {

    private var tvId:Int? = null

    fun setSelectedFilms(tvID:Int?){
        this.tvId = tvID
    }

    fun getTvDetail() :LiveData<TvDetailEntity> = filmRepository.getTvDetail(tvId)

    fun getTvGenre() :LiveData<List<GenreTvDetailEntity>> = filmRepository.getTvGenre(tvId)

    fun getTrailer() :LiveData<List<TvTrailerEntity>> = filmRepository.getTrailerTv(tvId)

}